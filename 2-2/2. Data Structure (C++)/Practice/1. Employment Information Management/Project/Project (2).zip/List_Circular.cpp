#include "List_Circular.h"

List_Circular::List_Circular()
{
	this->pHead = NULL;
}


List_Circular::~List_Circular()
{
	/* You must fill in here */
}

/* You must fill in the member function definitions of the List_Circular class here */
