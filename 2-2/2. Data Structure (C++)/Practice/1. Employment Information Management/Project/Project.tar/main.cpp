#include "Management.h"
#include<utility>
#include<cstring>
int main()
{
	Management m;

	m.ReadCommand();
	return 0;
}
