#include "BST.h"

BST::BST()
{
	this->root = NULL;
}

BST::~BST()
{
	/* You must fill in here */
}

/* You must fill in the member function definitions of the BST class here */
