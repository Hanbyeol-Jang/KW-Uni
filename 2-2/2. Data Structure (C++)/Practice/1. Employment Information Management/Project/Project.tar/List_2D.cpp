#include "List_2D.h"

List_2D::List_2D()
{
	this->pHead = NULL;
}


List_2D::~List_2D()
{
	/* You must fill in here */
}

/* You must fill in the member function definitions of the List_2D class here */
